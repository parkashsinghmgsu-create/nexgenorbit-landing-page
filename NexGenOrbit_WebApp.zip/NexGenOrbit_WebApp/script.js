// Mobile navigation toggle
const navbar = document.querySelector('.navbar');
const navLinks = document.querySelector('.nav-links');
const menuBtn = document.createElement('button');

menuBtn.className = 'menu-btn';
menuBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12l2-2m0 0l2-2m-2 0l2 2m2-2l-2 2m7-3v9m-6-3h6m4-3v12m-6-3h6m4-3v12m-6-3h6"/><circle cx="12" cy="12" r="1"/></svg>';

if (window.innerWidth < 968) {
  navbar.insertBefore(menuBtn, navLinks);
  menuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    menuBtn.innerHTML = navLinks.classList.contains('active')
      ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12l2-2m0 0l2-2m-2 0l2 2m2-2l-2 2m7-3v9m-6-3h6m4-3v12m-6-3h6m4-3v12m-6-3h6"/><circle cx="12" cy="12" r="1"/></svg>'
      : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12l2-2m0 0l2-2m-2 0l2 2m2-2l-2 2m7-3v9m-6-3h6m4-3v12m-6-3h6m4-3v12m-6-3h6"/><circle cx="12" cy="12" r="1"/></svg>';
  });
}

// Sticky header on scroll
let lastScroll = 0;
window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;
  
  if (currentScroll > lastScroll && currentScroll > 100) {
    navbar.style.transform = 'translateY(-100%)';
  } else {
    navbar.style.transform = 'translateY(0)';
  }
  
  lastScroll = currentScroll;
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Parallax effect for orbit spheres
document.addEventListener('mousemove', (e) => {
  if (window.innerWidth > 968) {
    const orbitSpheres = document.querySelectorAll('.orbit-layer');
    const xRatio = (e.clientX / window.innerWidth) - 0.5;
    const yRatio = (e.clientY / window.innerHeight) - 0.5;
    
    orbitSpheres.forEach((sphere, index) => {
      const speed = (index + 1) * 10;
      sphere.style.transform = `translate(${xRatio * speed}px, ${yRatio * speed}px)`;
    });
  }
});

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
  // Check reduced motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('.orbit-layer').forEach(sphere => {
      sphere.style.animation = 'none';
      sphere.style.opacity = '0.3';
    });
  }
  
  // Central logo mouse following
  const centralLogo = document.getElementById('centralLogo');
  if (centralLogo) {
    let mouseX = 0, mouseY = 0;
    let logoX = 0, logoY = 0;
    
    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });
    
    function animateLogo() {
      // Smooth follow with slight lag
      logoX += (mouseX - 40 - logoX) * 0.1;
      logoY += (mouseY - 40 - logoY) * 0.1;
      centralLogo.style.transform = `translate(${logoX}px, ${logoY}px)`;
      requestAnimationFrame(animateLogo);
    }
    
    // Start animation only on desktop
    if (window.innerWidth > 968) {
      animateLogo();
    }
    
    // Hide on mobile and reposition when resizing
    window.addEventListener('resize', () => {
      if (window.innerWidth <= 968) {
        centralLogo.style.display = 'none';
      } else {
        centralLogo.style.display = 'block';
        centralLogo.style.transform = 'translate(-50%, -50%)';
      }
    });
  }
});